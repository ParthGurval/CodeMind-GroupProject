KachaBazar Frontend Documentation

